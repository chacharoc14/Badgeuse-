# Neuro Stack Guide

## Installation

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

## Deploy

Push sur GitHub puis import sur Vercel.
