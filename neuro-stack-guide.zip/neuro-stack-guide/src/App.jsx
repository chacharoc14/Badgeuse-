export default function App() {
  return (
    <div className="min-h-screen bg-[#f7f2ea] text-black p-10">
      <h1 className="text-6xl font-black mb-6">Neuro Stack Guide</h1>
      <p className="text-xl max-w-2xl">
        Projet GitHub prêt à être déployé avec React + Vite + Tailwind.
      </p>
    </div>
  )
}
